package com.acn.training.poly;

/*  多态前提
 * 1）要有类的继续关系
 * 2）子类要有方法的重写
 * 
 * 
 * 
 * @author shaoge.zheng
 *
 */

public class TestPerson2 {

	public static void main(String[] args) {
		
		//Traditional way
		
		Person1 p1 = new Person1();
		func(p1);
		
		Man1 m1 = new Man1();
	    func(m1);
		
		Woman1 w1 = new Woman1();
	    func(w1);

	}
	
	
	public static void func( Person1 p)  // Person1 p = new Man1(); or Person1 p = new Woman1();
	
	{
		p.walk(); p.eat();
		
	}

}

