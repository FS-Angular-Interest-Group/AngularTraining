export class Book {
    name: string;
}

export const BOOKS = [
    {name: 'Java'},
    {name: 'HTML'},
    {name: 'JS'}
];
