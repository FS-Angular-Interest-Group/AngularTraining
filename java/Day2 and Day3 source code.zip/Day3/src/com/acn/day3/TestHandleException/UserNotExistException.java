package com.acn.day3.TestHandleException;

public class UserNotExistException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserNotExistException() {

	}

	public UserNotExistException(String msg) {

		super(msg);

	}

}
