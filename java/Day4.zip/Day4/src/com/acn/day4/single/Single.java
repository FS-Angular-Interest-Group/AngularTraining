package com.acn.day4.single;

//1. make contructor private, external programe can not use new instance

//2.The　instance only can be created internally by using 'static'


public class Single {

	 //case 2:
	
/*	private Single(){}

	static Single instance = new Single();
	*/

	
	//Case3:
	private Single(){}

	private static Single instance = new Single();
	
	public static Single getInstance()
	{
		return instance;
		
	}
	

}
