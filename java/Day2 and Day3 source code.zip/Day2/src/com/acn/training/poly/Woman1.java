package com.acn.training.poly;

public class Woman1 extends Person1 {
	

	
	public void walk()
	{
		System.out.println("Woman walk step by step..");
		
	}

   public void eat()
   {
	   
	   System.out.println("Woman eat a pieces and a piece...");
   }
   
   public void Shopping()
   {
	   
	   System.out.println("Woman is shopping ...");
   }

}
