package com.acn.day2;

public class HourlyEmployee extends Employee {
	private double hourSalary;
	private int hour;
	
	public HourlyEmployee(String name, int birth, double hourSalary, int hour) {
		super(name, birth);
		this.hour = hour;
		this.hourSalary = hourSalary;
	}
	
	public double getSalary(int month){
		if(160>this.hour){
			return this.hourSalary*this.hour+super.getSalary(month);
		}else{
			return this.hourSalary*160 + this.hourSalary*1.5*(this.hour-160)+super.getSalary(month);
		}
	}

}
