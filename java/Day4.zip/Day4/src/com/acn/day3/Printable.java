package com.acn.day3;

public interface Printable {

	public void printPerimeter();
	public void printArea();
}
