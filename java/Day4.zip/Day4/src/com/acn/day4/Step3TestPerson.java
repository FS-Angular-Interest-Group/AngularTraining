package com.acn.day4;

public class Step3TestPerson {
    public static void main(String[] args) {
	System.out.println("Number of total is " +Person.getTotalPerson());

//  what is the results?
	
	Person p1 = new Person();
 	System.out.println( "Number of total is "+ Person.getTotalPerson());
 	
 	
    }
}
