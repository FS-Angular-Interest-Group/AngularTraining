package com.acn.day3.String;

public class TestIndexOf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// What is the results ?

		String s = "https://www.accenture.com/adfs";

		int begin = s.indexOf("//") + 2;
		int end = s.lastIndexOf("/");
		String result = s.substring(begin, end);

		// System.out.println(begin);
		// System.out.println(end);

		System.out.println(result);

		// System.out.println(s.substring(1,11));
		// System.out.println(s.substring(8,18));

	}

}
