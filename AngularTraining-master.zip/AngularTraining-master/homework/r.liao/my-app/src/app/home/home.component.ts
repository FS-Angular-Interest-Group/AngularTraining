import {Component} from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'home',
  styleUrls: ['./home.component.css'],
  templateUrl: './home.component.html'
})
export class HomeComponent {
  constructor() {
  }
}
