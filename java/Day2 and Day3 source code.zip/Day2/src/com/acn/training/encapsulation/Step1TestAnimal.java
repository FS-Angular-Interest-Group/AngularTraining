package com.acn.training.encapsulation;

public class Step1TestAnimal {
	
	public static void main(String[] args){
	
		
	     Animal a = new Animal(); // 开辟区域存实体Animal
	     	  
	     System.out.println(a);   //输出地址值
	
		 
	}
     
	
}


class Animal{
	int legs;
	String eyeColor;
	
	
}
