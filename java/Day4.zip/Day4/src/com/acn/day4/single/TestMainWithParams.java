package com.acn.day4.single;

public class TestMainWithParams {

	public static void main(String[] args) {
	
		if (args!=null)
		{
			
			for (String arg:args){
				
				System.out.println("----->"+arg);
				
			}
		}
		
	}
}
