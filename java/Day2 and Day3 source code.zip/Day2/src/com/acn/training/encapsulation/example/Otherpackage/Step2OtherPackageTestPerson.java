package com.acn.training.encapsulation.example.Otherpackage;

import com.acn.training.encapsulation.example.Person; //need to import Person class !!

public class Step2OtherPackageTestPerson {

	public static void main(String[] args) {

		Person p = new Person();
	//	 System.out.println(p.age); //age is lost ? !
		// System.out.println(p.name); //name is lost ??
	 // System.out.println(p.weight); // weight is lost ?
		System.out.println(p.ismale);

	}

}
