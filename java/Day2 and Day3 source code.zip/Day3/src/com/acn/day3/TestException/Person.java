package com.acn.day3.TestException;

public class Person {
	
	void speak()
	{}
}
