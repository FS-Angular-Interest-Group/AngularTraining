package com.acn.day4.java;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import com.acn.day4.java.OuterClass.InnerClass;
import com.acn.day4.java.OuterClass.StaticInnerClass;

public class TestInnerClass {

	public static void main(String[] args) {

    // 1.Non static method

	/*	OuterClass oc = new OuterClass();
		
		InnerClass in = oc.new InnerClass();
		
		
		in.test();*/
		
	//2.Static method	
		
	// StaticInnerClass oc1 = new OuterClass.StaticInnerClass();
		 
	//	 oc1.test();
		 OuterClass oc = new OuterClass();
			InnerClass in = oc.new InnerClass();
			in.test();
		 

/*		Proxy.newProxyInstance(null, null, new InvocationHandler() {

			@Override
			public Object invoke(Object proxy, Method method, Object[] args)
					throws Throwable {
				// TODO Auto-generated method stub
				return null;
			}
		});

		InvocationHandler invocationHandler = new InvocationHandler() {
			@Override
			public Object invoke(Object proxy, Method method, Object[] args)
					throws Throwable {
				return null;
			}
		};*/

	}

}
