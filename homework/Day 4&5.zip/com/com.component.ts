import { Component, OnInit } from '@angular/core';
import { FormsModule} from '@angular/forms';

import { ActivatedRoute, ParamMap, Router } from '@angular/router';


@Component({
  selector: 'app-com',
  templateUrl: './com.component.html',
  styleUrls: ['./com.component.css']
})
export class ComComponent implements OnInit {

  test1 = 'rout1';
  title= 'app';
  id = '';

constructor(private route:ActivatedRoute) {
    this.route.params.subscribe(params => {
    this.id = params['id'];
})

    console.log(this.id);
}


  ngOnInit() {
  }


}
