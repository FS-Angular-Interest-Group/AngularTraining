package com.acn.day3.Testdate;

import java.text.DateFormat;
import java.util.Date;

public class TestDateFormat {

	public static void main(String[] args) {
		// TODO Auto-generated metho stub
		
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT);
		Date date = new Date();
		String dateStr = df.format(date);
		System.out.println(dateStr);
		

	}

}
