package com.acn.day3;

public class Rectangle implements Shape, Printable {
	
	private double length;
	private double width;
	
	public Rectangle(double length, double width){
		this.length =  length;
		this.width = width;
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return this.length*this.width;
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return (this.length+this.width)*2;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Rectangle";
	}

	@Override
	public void printArea() {
		System.out.println("Area: "+getArea());
		
	}

	@Override
	public void printPerimeter() {
		System.out.println("Perimeter: "+getPerimeter());		
	}
	
	public static void main(String[] args) {
		Rectangle r = new Rectangle(3,5);
		r.printArea();
		r.printPerimeter();
	}

}
