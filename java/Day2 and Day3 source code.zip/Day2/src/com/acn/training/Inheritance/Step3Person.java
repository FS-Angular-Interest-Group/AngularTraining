package com.acn.training.Inheritance;

public class Step3Person {

	private int age;
	String name;
	protected double weight;
	public boolean ismale;

	public void info() {
		// In its own class ,we can see 4 fields can be used
		System.out.println(this.age);
		System.out.println(this.name);
		System.out.println(this.weight);
		System.out.println(this.ismale);
	}
//Overwrite info with one parameter
	
	public void info(int n)

	{
		System.out.println(n);

	}

	@Override
	public String toString() {
		return "Person [age=" + age + ", name=" + name + ", weight=" + weight
				+ ", ismale=" + ismale + "+]";
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public boolean isIsmale() {
		return ismale;
	}

	public void setIsmale(boolean ismale) {
		this.ismale = ismale;
	}
	
	

}
