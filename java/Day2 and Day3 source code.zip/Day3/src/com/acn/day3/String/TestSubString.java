package com.acn.day3.String;

/*
 * SubString属于�?�闭�?�开 
 * 
 */
public class TestSubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "https://federation-sts.accenture.com/adfs";
		
	    String	Str1 = s.substring(0);
		String	Str2 = s.substring(1);
		
	
	    
	    System.out.println(Str1);
	    System.out.println(Str2);
	    
 //	System.out.println(s.substring(0,10));
	//System.out.println(s.substring(1,11));
	//System.out.println(s.substring(8,18));
		
	}

}
