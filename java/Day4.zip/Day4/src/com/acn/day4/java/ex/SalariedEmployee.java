package com.acn.day4.java.ex;


public class SalariedEmployee extends Employee{

	private int weeklySalary;
	
	public SalariedEmployee(String name, int number, MyDate birthday,
			int weeklySalary) {
		super(name, number, birthday);
		this.weeklySalary = weeklySalary;
	}

	@Override
	int earnings() {
		return weeklySalary;
	}
	
	@Override
	public String toString() {
		return "EmployeeType: SalariedEmployee, " + super.toString();
	}

	public int getWeeklySalary() {
		return weeklySalary;
	}

	public void setWeeklySalary(int weeklySalary) {
		this.weeklySalary = weeklySalary;
	}

	
}
