import { RoundupPipe } from './roundup.pipe';

describe('RoundupPipe', () => {
  it('create an instance', () => {
    const pipe = new RoundupPipe();
    expect(pipe).toBeTruthy();
  });
});
