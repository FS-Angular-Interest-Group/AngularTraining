package com.acn.day4;

public class Step5TestStatic2 {

	static String name;
	int age;

	// Constructor
	public Step5TestStatic2() {
		System.out.println("Step5TestStatic2 Constructor....");

	}

	// coding without parameters

	{
		age = 12;

		System.out.println("coding without parameters....");

	}
	// Account Contructor
	Account a1 = new Account(1000, "");

	// Static coding
	static {
		System.out.println("Static constructor...");

	}

	static void test() {
		name = "";
		// age=13; // we can not access age now!!
		// method();

	}

	void method() {
		age = 14;
		name = "";
		test();

	}

	public static void main(String[] args) {

	//	Step5TestStatic2 a = new Step5TestStatic2();

	// Step5TestStatic2.name= "Very good";

	}

}
