function firstTs() {
    return "Hello World";
}
document.body.innerHTML = firstTs();
