package com.acn.day4.java.ex;


public class PayrollSystem {
	
	public static void main(String[] args) {
		
		Employee [] emps = new Employee[5];
		
		emps[0] = new SalariedEmployee("Tom", 1001, new MyDate(4, 2, 1990), 200);
		emps[1] = new SalariedEmployee("Jerry", 1002, new MyDate(5, 2, 1989), 300);
		
		emps[2] = new HourlyEmployee("Mike", 1003, new MyDate(6, 4, 1987), 100,  4);
		emps[3] = new HourlyEmployee("Rose", 1004, new MyDate(4, 10, 1987), 200,  5);
		emps[4] = new HourlyEmployee("Bob", 1005, new MyDate(8, 4, 1987), 300,  4);
	
		for(Employee emp: emps){
			System.out.println(emp); 
			
			if(emp.getBirthday().getMonth() == 4){
				System.out.println("Brithday pay 100..");
			}
			
			System.out.println(); 
		}
	}
	
}
