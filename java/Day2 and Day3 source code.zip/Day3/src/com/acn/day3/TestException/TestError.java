package com.acn.day3.TestException;

public class TestError {

	public static void main(String[] args) {
		
     // main call main .... or IO can not be handled
		
		 main(new String[]{});
		 
		 
	}

}
