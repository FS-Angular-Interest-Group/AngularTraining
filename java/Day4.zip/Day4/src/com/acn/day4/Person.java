package com.acn.day4;

public class Person {
    private int id;
    private static int total = 0;
    public static int getTotalPerson() { 
	return total;
    }
    public Person() {
      	total++;
	id = total;
    }


}
