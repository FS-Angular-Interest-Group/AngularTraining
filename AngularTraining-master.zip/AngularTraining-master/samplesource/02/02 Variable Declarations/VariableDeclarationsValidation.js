function printLabel(labelledObj) {
    console.log(labelledObj.label);
}
var myObj = { label: " myObj ", value: "10" };
printLabel(myObj);
