package com.acn.day3;

public class Circle implements Shape, Printable {

	private double radius;
	
	public Circle(double radius){
		this.radius = radius;
	}
	
	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return Math.PI * Math.pow(radius,2);
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return Math.PI*2*radius;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Circle";
	}
	
	@Override
	public void printArea() {
		System.out.println("Area: "+getArea());
		
	}

	@Override
	public void printPerimeter() {
		System.out.println("Perimeter: "+getPerimeter());		
	}
	
	public static void main(String[] args) {
		Circle c = new Circle(1);
		c.printArea();
		c.printPerimeter();
	}

}
