package com.acn.training.encapsulation;

public class Step3TestAnimal {

	public static void main(String[] args) {

		Animal3 a = new Animal3(); // 开辟区域存实体Animal
        a.setLegs(5); // 但�?�?有化，还是有问题。
        a.legs=6;
        a.setEyeColor("Red");
		System.out.println(a); // 输出地�?�值
		

	}

}

class Animal3{
	int legs;
	String eyeColor;

	@Override
	public String toString() {
		return "Animal3 [legs=" + legs + ", eyeColor=" + eyeColor + "]";
	}

	public int getLegs() {
		return legs;
	}

	public void setLegs(int legs) {
		if(legs==2||legs==4||legs==8){
		this.legs = legs;
		}
		else{System.out.println("Invalid legs and please reset it!");}
	}

	public String getEyeColor() {
		return eyeColor;
	}

	public void setEyeColor(String eyeColor) {
		this.eyeColor = eyeColor;
	}
	
	

}