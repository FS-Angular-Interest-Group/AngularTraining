package com.acn.day2;

public class SalesEmployee extends Employee {

	private double sales;
	private double percentage;	
	
	public SalesEmployee(String name, int birth, double sales, double percentage) {
		super(name, birth);
		this.percentage = percentage;
		this.sales = sales;
	}
	
	public double getSalary(int month){
		return this.percentage*this.sales+super.getSalary(month);
	}

}
