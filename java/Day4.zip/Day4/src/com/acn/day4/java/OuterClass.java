package com.acn.day4.java;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class OuterClass {

	int age;

	static class StaticInnerClass {
		private String staticInnername = "Static Inner name ";

		void test() {
			// System.out.println(age);
			
			System.out.println(staticInnername);
		}
	}

	static String ourname = "Out name";
	
	private int i = 3;

	class InnerClass {
		
		private int i =2;
		
		private String innername = "In name";

		public void test() {
			
			 int i = 1;
			
			System.out.println(i);
		System.out.println(this.i);
		System.out.println(OuterClass.this.i);

			System.out.println("innername = " + innername);

			System.out.println("ourname =  " + ourname);
		}
	}

}
