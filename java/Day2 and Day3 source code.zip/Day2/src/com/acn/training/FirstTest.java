package com.acn.training;

public class FirstTest {
	
   public static void main(String[] args) {
	
	 //  int[] i = new int [4];
	   
	  // System.out.println(i[0]);
	//   System.out.println(i[4]);
	  // System.out.println(i.length);
	   
	// 这些是我们想打印的数字
	   int[] primes = new int[] { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29 };
	   // 这是打印这些数字的循环
	   for(int n : primes)
	   System.out.print(n+",");
	
	   	  
	   	  
	   	  
}

}
