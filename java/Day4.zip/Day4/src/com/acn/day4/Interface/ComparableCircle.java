package com.acn.day4.Interface;


public class ComparableCircle extends Circle implements CompareObject  {
	
//	protected double radius;
	
/*
public ComparableCircle(double radius) {
		super(radius);
}
*/
	@Override
	public int compareTo(Object o) {
		
		
		if(o instanceof Circle){
			Circle circle = (Circle) o;
		
			return (int)(this.radius - circle.getRadius());
		}
		
		return 0;
	}

}
