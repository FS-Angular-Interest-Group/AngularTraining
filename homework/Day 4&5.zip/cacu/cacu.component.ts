import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cacu',
  templateUrl: './cacu.component.html',
  styleUrls: ['./cacu.component.css']
})
export class CacuComponent implements OnInit {

  num: number;

  constructor() {console.log(this.num); }

  ngOnInit() {
  }

}
