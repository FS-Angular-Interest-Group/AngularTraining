package com.acn.day4.Interface;

public class OrderDAO implements DAO,Test {

	@Override
	public void save() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object get() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object[] query() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		
	}






}
