package com.acn.day3.TestHandleException;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.management.RuntimeErrorException;

public class TestThrows {

	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException {

		// test2();
		// test3(0);
		
	//	test1();

     	A a = new B();
		a.method1();

	}

	// use Throws to declare throwing Exception and do nothingn
	// The exception will throw to the function which call it.
	static void test1() throws FileNotFoundException, ClassNotFoundException {

	Class.forName("com.acn.day3.acb");
		

      
		
	}

	static void test2() throws ClassNotFoundException, ArithmeticException {

/*		Class.forName("com.acn.day3.acb");
		int j = 10 / 0;*/
		
	

	}

	static void test3(int i) {

		if (i == 0) {

			throw new ArithmeticException();
		}
	}


}


class A {

	void method1() throws FileNotFoundException {
	}

	void method2() throws NullPointerException {
	}

}

class B extends A {
	@Override
	void method1() throws FileNotFoundException {

		super.method1();
	}
//RuntimeException is the father class of NullPointerException, but why we can use this ?
	@Override
	void method2() throws RuntimeException {

		super.method2();
	

}
}
