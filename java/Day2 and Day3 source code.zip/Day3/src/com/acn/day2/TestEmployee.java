package com.acn.day2;

import java.util.ArrayList;
import java.util.List;

public class TestEmployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(new SalariedEmployee("A", 3, 5000));
		employeeList.add(new HourlyEmployee("B", 2, 30, 200));
		employeeList.add(new SalesEmployee("C", 10, 100000, 0.08));
		employeeList.add(new BasePlusSalesEmployee("D", 12, 200000, 0.05, 3000));
		
		System.out.println("XXX Company 2nd month Employee Salary List");
		double totalSalary=0;
		for(Employee employee : employeeList){
			totalSalary = totalSalary + employee.getSalary(2);
			System.out.println(employee.getName()+"       "+employee.getSalary(2));			
		}
		System.out.println("Total"+"   "+totalSalary);

	}

}
