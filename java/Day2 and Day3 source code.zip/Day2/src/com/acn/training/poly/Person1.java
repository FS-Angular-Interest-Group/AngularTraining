package com.acn.training.poly;

public class Person1 {

	public void walk() {
		System.out.println("Person walk...");
	}

	public void eat() {

		System.out.println("Person eat...");
	}

}
