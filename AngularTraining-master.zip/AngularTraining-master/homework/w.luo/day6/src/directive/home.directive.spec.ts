import { HomeDirective } from './home.directive';

describe('HomeDirective', () => {
  it('should create an instance', () => {
    const directive = new HomeDirective();
    expect(directive).toBeTruthy();
  });
});
