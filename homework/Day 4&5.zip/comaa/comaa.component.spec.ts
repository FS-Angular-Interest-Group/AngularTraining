import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComaaComponent } from './comaa.component';

describe('ComaaComponent', () => {
  let component: ComaaComponent;
  let fixture: ComponentFixture<ComaaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComaaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComaaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
