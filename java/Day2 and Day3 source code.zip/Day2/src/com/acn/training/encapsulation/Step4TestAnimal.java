package com.acn.training.encapsulation;

public class Step4TestAnimal {

	public static void main(String[] args) {

		Animal4 a = new Animal4(); // 开辟区域存实体Animal
        
		a.setEyeColor("Blue");
		a.setLegs(8);
	//	 a.legs=6;
		
		System.out.println(a.getLegs()); // 输出地�?�值
		

	}

}

class Animal4{
	private int legs;
	private String eyeColor;

	@Override
	public String toString() {
		return "Animal4 [legs=" + legs + ", eyeColor=" + eyeColor + "]";
	}

	public int getLegs() {
		return legs;
	}

	public void setLegs(int legs) {
		if(legs==2||legs==4||legs==8){
		this.legs = legs;
		}
		else{System.out.println("Invalid legs and please reset it!");}
	}

	public String getEyeColor() {
		return eyeColor;
	}

	public void setEyeColor(String eyeColor) {
		this.eyeColor = eyeColor;
	}
	
	

}