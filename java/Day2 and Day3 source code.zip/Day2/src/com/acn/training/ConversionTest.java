package com.acn.training;

public class ConversionTest{
	public static void main(String[] args) {
		double d = 13.4;
		long l = (long)d;
		System.out.println(l);
		int in = 5;
      //boolean b = (boolean)in;
		Object obj = "Hello";
		String objStr = (String)obj;
		System.out.println(objStr);
		Object objPri = new Integer(5);
		//所以下面代码运行时引发ClassCastException异常
		String str = (String)objPri;
	}
}
