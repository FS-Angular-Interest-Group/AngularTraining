package com.acn.training;

public class TestJavaBean {
	
	private String name;
	private boolean isCheck;
	private int salary;
	private double bonus;
	
	
	public String getName()
	{
	 return name;
	}
	
	public void setName (String name)
	{
		
	  
	  this.name = name;
	}

}
