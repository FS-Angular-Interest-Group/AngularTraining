package com.acn.day3.StringBuffer;

public class Step1TestStringBuffer {

	public static void main(String[] args) {

		StringBuffer sb = new StringBuffer("abcde");

		System.out.println("Stringbuffer is " + sb);

		String s = new String("abcde");

		System.out.println("String is " + s);

		sb.replace(0, 2, "AC");
		
		System.out.println("Stringbuffer is " + sb);

		s.replace("a", "AC");

		System.out.println("String is " + s);

	}
}
