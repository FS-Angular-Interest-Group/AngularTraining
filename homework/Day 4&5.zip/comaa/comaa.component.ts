import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comaa',
  templateUrl: './comaa.component.html',
  styleUrls: ['./comaa.component.css']
})
export class ComaaComponent implements OnInit {
  NAME = 'ARRON';
  constructor() { }
  ngOnInit() {
  }

}
