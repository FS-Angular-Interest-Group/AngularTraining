package com.acn.day4;

public class Account {
	
	private int id;
	private int balance;
	private String password;
	
	private static double interestRate;
	private static double minBalance;
	private static int initID =100000;
	
	
	
	public Account(int balance, String password) {
		
		id = initID++;
		
		this.balance = balance;
		this.password = password;
		
	//	System.out.println("Account Contructor..");
	}



	@Override
	public String toString() {
		return "Account [id=" + id + ", balance=" + balance + ", password="
				+ password + "]";
	}
	
	

}
