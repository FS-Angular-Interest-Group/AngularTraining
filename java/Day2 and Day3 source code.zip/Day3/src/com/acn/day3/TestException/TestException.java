package com.acn.day3.TestException;

public class TestException {

	public static void main(String[] args) {
		
		//1 - 4 RunTimeExcetpion 

		// 1.Java.lang.ArrayIndexOutofBoundsException

		int[] scores = new int[10];

		 scores[10]=100;

		// 2. Null pointer Exception

		//int[][] yh = new int[10][];

		//yh[0][0]=10;

		Person p = null;

		 p.speak();

		// 3. java.lang.ArithmeticException:

		// int i = 10/0;

		// 4.java.lang.ClassCastException:

		Object obj = new TestException();
		Person p2 = (Person) obj;
		
		//Compile exception
		
	//	Class.forName("com.acn.day3.TestException.Person");

	}

}
