package com.acn.day2;

public class Employee {
	private String name;
	private int birth;
	
	public Employee(String name, int birth){
		this.name = name;
		this.birth = birth;
	}
	
	public double getSalary(int month){
		if(month==this.birth){
			return 100;
		}else{
			return 0;
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
