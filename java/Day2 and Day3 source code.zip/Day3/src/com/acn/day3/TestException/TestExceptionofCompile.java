package com.acn.day3.TestException;

import java.io.FileInputStream;

public class TestExceptionofCompile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	//FileInputStream fs = new FileInputStream("");

	}

}
