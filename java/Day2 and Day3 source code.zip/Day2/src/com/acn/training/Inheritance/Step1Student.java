package com.acn.training.Inheritance;

//Children get all the things from Farther class. But just use getter/setter to access father's private things

import com.acn.training.encapsulation.example.Person;

public class Step1Student extends Person {

	public static void main(String[] args) {

		Step1Student p = new Step1Student();
		// System.out.println(p.age); //age is lost ? !
		// System.out.println(p.name);
	
		System.out.println(p.weight);
		System.out.println(p.ismale);
	
		System.out.println(p.toString()); // we can use father class's method

	}
}