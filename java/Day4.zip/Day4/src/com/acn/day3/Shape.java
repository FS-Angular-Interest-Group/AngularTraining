package com.acn.day3;

public interface Shape {

	public double getPerimeter();
	public double getArea();
	public String getName();
}
