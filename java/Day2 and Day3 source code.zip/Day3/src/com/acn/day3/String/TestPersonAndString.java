package com.acn.day3.String;


public class TestPersonAndString {

	public static void changeperson(Person p) {
		p.setName("Accenture");

	}

	public static void changestring(String s) {

		s.replace('A', 'W');
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Person("jack", 12);
		System.out.println(p);
		
		//Change Person
		changeperson(p);
		System.out.println(p);
		
		//Change String
		String s = "ABCD";
		changestring(s);
		System.out.println(s);

	}

}
