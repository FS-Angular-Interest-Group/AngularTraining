package com.acn.day4;

public class Step4TestAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Account a1 = new Account(100, "888888");

		System.out.println(a1);

		Account a2 = new Account(111, "password");

		System.out.println(a2);

		Account a3 = new Account(222, "888888");

		System.out.println(a3);

	}

}
