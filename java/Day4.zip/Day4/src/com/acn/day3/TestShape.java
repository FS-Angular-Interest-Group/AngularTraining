package com.acn.day3;

import java.util.ArrayList;
import java.util.List;

public class TestShape {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Shape> shapeList = new ArrayList<Shape>();
		Shape s0 = new Rectangle(3,5);
		Shape s1 = new Triangle(2,4,5);
		Shape s2 = new Circle(1);
		shapeList.add(s0);
		shapeList.add(s1);
		shapeList.add(s2);
		for(Shape shape : shapeList){			
			System.out.println(shape.getName()+"   "+shape.getPerimeter()+"   "+shape.getArea());
			
		}
		
	}

}
