package com.acn.day4.Interface;

public class TestCompareCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ComparableCircle c1 = new ComparableCircle();
		c1.setRadius(8);

		ComparableCircle c2 = new ComparableCircle();
		c2.setRadius(8);

		System.out.println(c1.compareTo(c2));

	}

}
