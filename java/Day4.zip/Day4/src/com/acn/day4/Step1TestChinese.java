package com.acn.day4;

public class Step1TestChinese {

	public static void main(String[] args) {
	
		Chinese c1 = new Chinese("China","Xiaoming","23" );       
		
		System.out.println(c1);	
		
		Chinese c2 = new Chinese("Great China of Earth","Xioahong","23" );       
		
	
		
		System.out.println(c1);
		
		System.out.println(c2);	
		
	}

}
