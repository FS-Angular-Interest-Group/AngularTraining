package com.acn.training;

public class AddWholeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int total = 0;
		for (int i = 1; i <= 50; i++)
			total = total + i;
		System.out.println("The whole number is " + total);

	}

}
