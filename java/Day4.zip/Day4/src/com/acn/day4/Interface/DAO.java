package com.acn.day4.Interface;

public interface DAO {
	
	//It means 'public static final' as below
	
	String QUERY_SQL = "SELECT..." ;
	
	
	//it means 'public abstract' 
	 void save();
	
	Object get();
	
	void delete();
	
	Object [] query();
	
	
	

}
