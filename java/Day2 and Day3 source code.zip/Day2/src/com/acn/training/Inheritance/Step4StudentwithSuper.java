package com.acn.training.Inheritance;

//Children get all the things from Farther class. But just use getter/setter to access father's private things

import com.acn.training.encapsulation.example.Person;

public class Step4StudentwithSuper extends Step3Person {

	public String toString() {
		return "Student [age=" + this.getAge() + ", name=" + getName()
				+ ", weight=" + weight + ", ismale=" + ismale + "+]";
	}

	//use super to get father method
	public String show()

	{
		return super.toString();

	}
	
	public void info(int n)

	{
		System.out.println(n);

	}

	public static void main(String[] args) {

		Step4StudentwithSuper p = new Step4StudentwithSuper();

		System.out.println(p.show()); // we can use father class's method by super

	}
}
