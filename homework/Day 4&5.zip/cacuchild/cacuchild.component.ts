import { Component, OnInit } from '@angular/core';
import {Input, Output} from '@angular/core';

@Component({
  selector: 'app-cacuchild',
  templateUrl: './cacuchild.component.html',
  styleUrls: ['./cacuchild.component.css']
})
export class CacuchildComponent implements OnInit {

   @Input() numchild: number;
  constructor() {


   }

  ngOnInit() {
    console.log(this.numchild);
  }

  decrease(){
      this.numchild--;

  }



 caculator() {
    window.setInterval(() => {
    this.decrease()}, 1000); 


 }



}
