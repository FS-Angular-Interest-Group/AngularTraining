package com.acn.day3.StringBuffer;

public class Step2StepStringAppend {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer(5);// What if StringBuffer(5) ? 
		sb.append("<html>")
		  .append("<body>")
		  .append("</body>")
		  .append("</html>") ;
		  
		System.out.print(sb);

	}

}
