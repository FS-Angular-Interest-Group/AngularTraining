package com.acn.day3.String;
/*
 * 
 * 字符串缓冲池，通过=赋值，会先在缓冲池中查找有无一样的字符串，1）有，把引用付给�?��?；2） 无，创建新的，并把字符串放入缓冲池中。
 */

public class TestStringEqual {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1 = "Hello World";
		String str2 = "Hello World";
		System.out.println(str1==str2);
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		
		

	}

}
