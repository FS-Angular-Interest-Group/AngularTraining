package com.acn.day4.single;

public class TestSingle {

	public static void main(String[] args) {

		// Case 1: It is not singleton
		
/*		 Single s1 = new Single(); 
		 Single s2 = new Single();
		 System.out.println(s1==s2);*/
		 
		
		

		// Case 2: Is it good Singlton ? Thinking about it

	/*	Single s1 = Single.instance;
		Single s2 = Single.instance;
		
		Single.instance =null;
		
		Single s3 = Single.instance;
		
		System.out.println(s3);
		*/
		// Case 3:
	/*	Single s1 = Single.getInstance();
		Single s2 = Single.getInstance();

		System.out.println(s1 == s2);*/

		// Can we set Single.getInstance is null ?

		// Single.getInstance() =null;

	}

}
