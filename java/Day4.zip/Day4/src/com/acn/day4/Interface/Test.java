package com.acn.day4.Interface;

public interface Test {
	
	void method1();
	
    void method2();

}
