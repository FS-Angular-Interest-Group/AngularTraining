package com.acn.day4.Interface;

interface CompareObject{
	
	public int compareTo(Object o);  
}
