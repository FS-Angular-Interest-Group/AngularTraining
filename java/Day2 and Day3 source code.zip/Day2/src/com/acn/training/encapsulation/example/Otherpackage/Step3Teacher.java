package com.acn.training.encapsulation.example.Otherpackage;

import com.acn.training.encapsulation.example.Person; //need to import Person class !!

public class Step3Teacher extends Person {

	public static void main(String[] args) {

		Step3Teacher p = new Step3Teacher(); //Create Step3Teacher class instead of Person class
	//	System.out.println(p.age); //age is lost ? !
	//	 System.out.println(p.name); //name is lost ??
		System.out.println(p.weight); // weight is coming ? :)
		System.out.println(p.ismale);
		

	}

}
