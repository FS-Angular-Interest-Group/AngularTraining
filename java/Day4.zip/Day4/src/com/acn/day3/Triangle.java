package com.acn.day3;

public class Triangle implements Shape, Printable {

	private double a;
	private double b;
	private double c;
	
	public Triangle(double a, double b, double c){
		this.a = a;
		this.b = b;
		this.c = c;
	}
	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		double p = (a+b+c)/2;
		return Math.sqrt(p*(p-a)*(p-b)*(p-c));
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return a+b+c;
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Triangle";
	}
	
	@Override
	public void printArea() {
		System.out.println("Area: "+getArea());
		
	}

	@Override
	public void printPerimeter() {
		System.out.println("Perimeter: "+getPerimeter());		
	}
	
	public static void main(String[] args) {
		Triangle t = new Triangle(2,4,5);
		t.printArea();
		t.printPerimeter();
	}

}
