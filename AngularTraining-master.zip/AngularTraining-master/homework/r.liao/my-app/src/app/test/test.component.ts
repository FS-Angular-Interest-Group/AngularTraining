import {Component} from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'test',
  styleUrls: ['./test.component.css'],
  templateUrl: './test.component.html'
})
export class TestComponent {
}
