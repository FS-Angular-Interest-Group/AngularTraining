package com.acn.day4;

public class Step2TestStatic {

	static String name;
	int age;

	static void test() {
		name = "";
	//	 age=13;  //  can we access age ?
	 //  method(); // can we access method ?

	}

	void method() {
		
		name = "";
		age = 14;  // can we access age ?
		test();   // can we access method ?

	}

	public static void main(String[] args) {

		// 1.How to access age ? We have to new object
		Step2TestStatic ts = new Step2TestStatic();
		ts.name = "Arthur";
		ts.age = 12;
		
		System.out.println(ts.name);

		// 2.You can see name can be accessed directly

		name = "Peter";
		
		System.out.println(ts.name);
		
		Step2TestStatic ts2 = new Step2TestStatic();
		
		// 3. You can change the name to see 
		
		ts2.name = "Accenture";
		
		System.out.println(ts.name);
		

	}

}
