package com.acn.day3.TestHandleException;

public class TestFinalException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// test();
		System.out.println(test2());
		
	//	System.out.println("End in main");

	}

	public static void test() {

		int j = 10 / 0;
	}

	public static int test2() {
		try {
			int j = 10 / 0;

		} catch (Exception e)

		{
			e.printStackTrace();
			 return 1;
		} finally {
			System.out.println("Finally..");
	}

		return 0;

	}
}
