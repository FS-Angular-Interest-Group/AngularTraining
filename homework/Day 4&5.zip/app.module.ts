import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ComComponent } from './com/com.component';
import { RouterModule, Routes } from '@angular/router';
import { ComaaComponent } from './comaa/comaa.component';
import { CacuComponent } from './cacu/cacu.component';
import { CacuchildComponent } from './cacuchild/cacuchild.component';
import { FormsModule } from '@angular/forms';

const appRoutes: Routes = [
  { path: 'abcd/:id', component: ComComponent, pathMatch: 'full'},
  { path: 'name', component: ComaaComponent, pathMatch: 'full'},
  { path: 'cacu', component: CacuComponent, pathMatch: 'full'}

];


@NgModule({
  declarations: [
    AppComponent,
    ComComponent,
    ComaaComponent,
    CacuComponent,
    CacuchildComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoutes
    )

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
