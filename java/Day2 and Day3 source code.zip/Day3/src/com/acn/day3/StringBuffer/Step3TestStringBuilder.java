package com.acn.day3.StringBuffer;

public class Step3TestStringBuilder {

	
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();// What if StringBuffer(5) ? 
		sb.append("<html>")
		  .append("<body>")
		  .append("</body>")
		  .append("</html>") ;
		  
		System.out.print(sb);

	}
	
	
	
}
