package com.acn.day4;

public class Chinese {

	//private static String country;
	
	private static String country;
	private String name;
	private String age;
	
	Chinese (String country,String name,String age){
		this.country=country;
		this.name=name;
		this.age=age;
		
		
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Chinese [country=" + country + ", name=" + name + ", age="
				+ age + "]";
	}
	
	
	
}
