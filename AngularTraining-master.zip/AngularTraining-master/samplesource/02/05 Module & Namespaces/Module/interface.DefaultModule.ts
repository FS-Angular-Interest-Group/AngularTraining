export default interface MyDefaultModule {
    doCheck(str: string): boolean;
}