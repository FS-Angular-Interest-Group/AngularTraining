package com.acn.day3.String;

/*
 * 
 * String 不可变的序列
 */

public class StringTest {

	public static void main(String[] args) {

		String str = "www.accenturee.com"; //it can not be changed after setting value

		System.out.println(str); //what is the result?
		
		String str2 = str.replace('c', 'C');

		System.out.println(str2); //what is the result?

		//String str1=str.replace('c', 'C');
		//System.out.println(str1);
	}

}