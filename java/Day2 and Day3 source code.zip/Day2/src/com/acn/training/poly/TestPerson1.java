package com.acn.training.poly;

/*  多态前提
 * 1）要有类的继续关系
 * 2）子类要有方法的重写
 * 
 * 
 * 
 * @author shaoge.zheng
 *
 */

public class TestPerson1 {

	public static void main(String[] args) {
		
		//Traditional way
		
		Person1 p1= new Person1();
		p1.walk();
		p1.eat();
		
		Man1 m1 = new Man1();
		m1.walk();
		m1.eat();
     	m1.smoking();
		
		Woman1 w1 = new Woman1();
		w1.walk();
		w1.eat();
      w1.Shopping();
		
		System.out.println("######################################");
		
//let's see how Polymorphism works
		
		Person1 p2 = new Man1();
		
		p2.walk();
		p2.eat();
	//p2.smoking();  there is no Smoking method in Person class but in Man1 Class
		
		
		p2 = new Woman1();
		
		p2.walk();
		p2.eat();  

	}

}
