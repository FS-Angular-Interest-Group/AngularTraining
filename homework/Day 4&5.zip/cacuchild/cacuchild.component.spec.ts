import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CacuchildComponent } from './cacuchild.component';

describe('CacuchildComponent', () => {
  let component: CacuchildComponent;
  let fixture: ComponentFixture<CacuchildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CacuchildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CacuchildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
