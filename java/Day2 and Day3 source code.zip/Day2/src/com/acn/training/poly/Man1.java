package com.acn.training.poly;

public class Man1 extends Person1 {
	
	
	public void walk()
	{
		System.out.println("Man walk faster..");
		
	}

   public void eat()
   {
	   
	   System.out.println("Man eat a lot...");
   }
   
   public void smoking()
   {
	   
	   System.out.println("Man is smoking..");
   }
}
//superman
//superwoman