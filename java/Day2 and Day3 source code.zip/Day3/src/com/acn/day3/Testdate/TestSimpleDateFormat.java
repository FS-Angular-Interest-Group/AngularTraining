package com.acn.day3.Testdate;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestSimpleDateFormat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DateFormat df = new SimpleDateFormat("yyy-MM-dd hh:mm:ss");
		Date date = new Date();
		String dateStr = df.format(date);
		System.out.println(dateStr);
		
		System.out.println("END....");
	
	    dateStr = "2008-12-12 2312:12"; //what we need to use exception handing here ?
	  try {
			date = df.parse(dateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    System.out.println(date);
	    
	  
		
	}

}
