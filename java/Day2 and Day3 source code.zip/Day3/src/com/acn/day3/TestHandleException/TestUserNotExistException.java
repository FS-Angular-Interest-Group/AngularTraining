package com.acn.day3.TestHandleException;

import java.util.Arrays;
import java.util.List;

public class TestUserNotExistException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String user = "TOM";
		
		try{

		Object result = getUser1(user);
		
		}
		catch(UserNotExistException e)
		{
			System.out.println(e.getMessage());
		}

	//	System.out.println(result);
	/*	if (result != null)

		{
			throw new UserNotExistException("Users not found..");

		}
		*/
		
		
	}

	public static Object getUser(String user) {
		return null;
	}

	public static User getUser1(String user)

	{
		List<String> users = Arrays.asList("AA", "BB", "CC");

		if (users.contains(user)) {
			return new User();
		} else {
			throw new UserNotExistException("users not found");
		}

	}
}
