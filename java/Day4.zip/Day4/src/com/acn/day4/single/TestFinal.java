package com.acn.day4.single;

public class TestFinal {

	public static void main(String[] args) {

	}
	
	class BB extends AA{
	/*	
		void finalMethod(){
			
			super.finalMethod();
		}*/
	}

	class AA {
		final void finalMethod() {
		}

		// final int age ;
		final int age;
		{
			age = 12;

		}
		final String name = "";

		final String sex;

		AA() {

			sex = "male";
		}

	}

}
