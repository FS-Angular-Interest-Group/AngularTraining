package com.acn.day2;

public class SalariedEmployee extends Employee {
	private double salary;
	
	public SalariedEmployee(String name, int birth, double salary) {
		super(name, birth);
		this.salary = salary;
	}

	public double getSalary(int month) {
		return salary + super.getSalary(month);
	}
}
