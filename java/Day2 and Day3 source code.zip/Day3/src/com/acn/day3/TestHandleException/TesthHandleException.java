package com.acn.day3.TestHandleException;

public class TesthHandleException {

	public static void main(String[] args) {
		// You need to know which exception to handle fist.e.g. Arthi Exception

	//int j = 10/0;
		
	
		
		try {
			int j = 10 / 0;
		} catch (ArithmeticException e) {
			System.out.println(e.getStackTrace());
			// do nothing
		}
		// catch (NullPointerException e) {
			
	//    } 
		// can RuntimeException put on th top ?
	catch(RuntimeException e) {
	    	
	   }
		
		System.out.println("end....");
	}

}
