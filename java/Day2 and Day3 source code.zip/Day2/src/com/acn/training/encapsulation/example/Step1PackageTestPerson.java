package com.acn.training.encapsulation.example;

public class Step1PackageTestPerson {

	public static void main(String[] args) {
		
		Person p = new Person();
		
		p.hashCode();
		
		//.out.println(p.age); //age is lost ? !
		System.out.println(p.name);
		System.out.println(p.weight);
		System.out.println(p.ismale);

}
}

	

	
