package com.acn.day3.Testdate;

import java.util.Date;

public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Date d = new Date();
		
		System.out.println(d);

	}

}
