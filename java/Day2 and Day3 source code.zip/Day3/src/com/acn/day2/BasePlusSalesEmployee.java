package com.acn.day2;

public class BasePlusSalesEmployee extends SalesEmployee {

	private double baseSalary;

	public BasePlusSalesEmployee(String name, int birth, double sales,
			double percentage, double baseSalary) {
		super(name, birth, sales, percentage);
		this.baseSalary = baseSalary;
	}
	
	public double getSalary(int month){
		return this.baseSalary + super.getSalary(month);
	}


}
