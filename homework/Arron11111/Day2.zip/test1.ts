interface getperson {
    showbody();
}

class personshower implements getperson {
    shower:string;
    hah:number;
    constructor(message: string, hah:number) {
        this.shower = message;
        this.hah=hah;
    }
    showbody(){
        console.log(this.shower);
    }

}


let haha = new personshower("red",2);
console.log(haha.showbody());
