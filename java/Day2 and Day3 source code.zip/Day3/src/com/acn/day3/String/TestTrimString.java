package com.acn.day3.String;

public class TestTrimString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "   AB C D E ";
		
		System.out.println(s.trim());

	}

}
