package com.acn.training.encapsulation;

public class Step2TestAnimal {

	public static void main(String[] args) {

		Animal2 a = new Animal2(); // 开辟区域存实体Animal
		
		a.eyeColor="Red";
		a.legs=4;

		System.out.println(a); // 输出
		// 还�?�以进行赋值�? print

	}

}

class Animal2 {
	int legs;
	String eyeColor;

	@Override
	public String toString() {
		return "Animal2 [legs=" + legs + ", eyeColor=" + eyeColor + "]";
	}

}
