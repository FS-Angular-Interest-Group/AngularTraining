import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CacuComponent } from './cacu.component';

describe('CacuComponent', () => {
  let component: CacuComponent;
  let fixture: ComponentFixture<CacuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CacuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CacuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
